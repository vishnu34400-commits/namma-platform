# ನಮ್ಮ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ — Namma-Platform

**MindMatrix VTU Internship Program — Project 11**  
*Android App Development using GenAI*

---

## 📌 Project Overview

Namma-Platform is a **Kannada-first railway station assistant** for rural and small railway stations in Karnataka. It helps passengers — especially elderly and non-English-speaking travellers — identify:

- ✅ Platform numbers (with large railway-board display)
- ✅ Coach positions (Engine → General → S1 → Ladies)
- ✅ General & Ladies coach locations (highlighted)
- ✅ Kannada voice announcements via TTS

---

## 🚀 Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 8+
- Android SDK 34
- Gradle 8.2+

### Steps to Run

1. **Clone / Open the project**
   ```
   Open Android Studio → File → Open → Select /NammaPlatform folder
   ```

2. **Gradle Sync**
   ```
   Wait for "Gradle sync" to complete automatically
   If it doesn't start: File → Sync Project with Gradle Files
   ```

3. **Run the app**
   ```
   Connect an Android device (API 21+) or start an emulator
   Click the green ▶ Run button
   ```

4. **For Kannada TTS** (on emulator):
   ```
   Settings → General Management → Language and Input
   → Text-to-Speech → Preferred Engine → Install Kannada language pack
   ```
   On many devices Kannada TTS falls back to English automatically — the app handles this gracefully.

---

## 📁 Folder Structure

```
NammaPlatform/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── trains.json              ← Local train data
│   │   ├── java/com/nammaplatform/
│   │   │   ├── activities/
│   │   │   │   ├── SplashActivity.kt    ← Entry point with animation
│   │   │   │   └── MainActivity.kt      ← Navigation host
│   │   │   ├── adapters/
│   │   │   │   ├── TrainAdapter.kt      ← RecyclerView for train list
│   │   │   │   └── CoachLayoutAdapter.kt← Horizontal coach strip
│   │   │   ├── models/
│   │   │   │   ├── Train.kt             ← Data model (maps to JSON)
│   │   │   │   └── Station.kt           ← Station model
│   │   │   ├── repository/
│   │   │   │   └── TrainRepository.kt   ← Data access layer
│   │   │   ├── utils/
│   │   │   │   ├── KannadaTTSHelper.kt  ← Text-to-Speech wrapper
│   │   │   │   └── CoachType.kt         ← Coach type enum
│   │   │   ├── viewmodel/
│   │   │   │   └── TrainViewModel.kt    ← MVVM ViewModel
│   │   │   └── ui/
│   │   │       ├── HomeFragment.kt      ← Train list screen
│   │   │       └── TrainDetailFragment.kt← Detail + TTS screen
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_splash.xml
│   │       │   ├── activity_main.xml
│   │       │   ├── fragment_home.xml
│   │       │   ├── fragment_train_detail.xml
│   │       │   ├── item_train.xml
│   │       │   └── item_coach.xml
│   │       ├── navigation/
│   │       │   └── nav_graph.xml
│   │       ├── anim/
│   │       │   ├── slide_in_right.xml
│   │       │   ├── slide_out_left.xml
│   │       │   ├── slide_in_left.xml
│   │       │   └── slide_out_right.xml
│   │       ├── drawable/
│   │       │   ├── ic_train.xml
│   │       │   ├── ic_launcher.xml
│   │       │   ├── bg_platform_badge.xml
│   │       │   ├── bg_status_on_time.xml
│   │       │   └── bg_status_late.xml
│   │       └── values/
│   │           ├── colors.xml
│   │           ├── strings.xml
│   │           └── themes.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## ✅ Testing Checklist

| Feature | How to Test | Expected Result |
|---------|-------------|-----------------|
| Splash screen | Launch app | Blue screen, train logo animates in, transitions to home in ~2.5s |
| Train list | Home screen | 6 trains shown in cards with name, number, platform, arrival time |
| Status badge | Check train cards | "On Time" = green badge, "Late" = red badge |
| Platform display | Tap any train | Large platform number on dark board (like a real railway LED board) |
| Coach layout | Train detail screen | Horizontal strip: General = yellow, Ladies = pink, Sleeper = blue |
| Kannada TTS | Tap "Speak" button | Hears announcement in Kannada (or English fallback) |
| Empty state | Rename trains.json | Empty state UI shown with retry button — no crash |
| Back navigation | Press back from detail | Returns to home, back button visible in toolbar |
| Offline mode | Turn off WiFi/data | App works fully offline (all data is local) |

---

## 🏗️ Architecture: MVVM

```
View (Fragment/Activity)
    ↕  observes LiveData
ViewModel
    ↕  calls suspend fun
Repository
    ↕  reads from
assets/trains.json
```

**Why MVVM?**
- Fragment doesn't talk directly to data — it observes ViewModel
- ViewModel survives screen rotation (no data re-fetch on rotate)
- Repository can be swapped for a real API later with zero Fragment changes

---

## 🔮 Future Enhancements

1. **Real-time API** — Integrate Indian Railways NTES API for live train status
2. **Firebase** — Sync train data from Firestore for multiple stations  
3. **Dark mode** — Add `values-night/themes.xml` for dark theme
4. **Voice search** — "ಮೈಸೂರು ರೈಲು" voice input using SpeechRecognizer
5. **Multi-station** — Station picker with trains filtered per station
6. **Animated train** — Moving train animation showing coach position approach
7. **Kannada/English toggle** — Switch all UI text between languages
8. **Notifications** — Alert when train is 15 minutes away

---

## 🎯 Success Criteria (VTU Submission)

- [x] Coach layout is visually clear with highlighted General/Ladies coaches
- [x] Kannada audio announcement works (or English fallback is clear)
- [x] High-contrast Blue (#0D47A1) and Yellow (#FFD600) UI throughout
- [x] App works fully offline
- [x] No crashes on any tested scenario

---

## 👨‍💻 Tech Stack

| Technology | Usage |
|---|---|
| Kotlin | Primary language |
| MVVM Architecture | Separation of concerns |
| Material Design 3 | UI components |
| Navigation Component | Fragment navigation |
| ViewBinding | Type-safe view access |
| Gson | JSON parsing |
| TextToSpeech API | Kannada announcements |
| Coroutines | Async data loading |
| LiveData | Reactive UI updates |
| RecyclerView | Train list + coach strip |

---

*Built for MindMatrix VTU Internship Program — Bengaluru, Karnataka 🇮🇳*
