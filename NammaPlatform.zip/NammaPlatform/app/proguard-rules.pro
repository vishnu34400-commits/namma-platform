# Keep Train model class for Gson serialization
-keep class com.nammaplatform.models.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
