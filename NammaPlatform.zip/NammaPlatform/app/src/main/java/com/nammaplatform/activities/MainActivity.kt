package com.nammaplatform.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.nammaplatform.R
import com.nammaplatform.databinding.ActivityMainBinding

/**
 * MainActivity — the single Activity that hosts all Fragments.
 *
 * This is the "shell" of the app. It sets up:
 * - ViewBinding for the layout
 * - Navigation Component (NavController + NavHostFragment)
 * - ActionBar integration with Navigation (back button auto-handled)
 *
 * All actual UI logic lives in the Fragments (HomeFragment, TrainDetailFragment).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the toolbar as the ActionBar
        setSupportActionBar(binding.toolbar)

        // Get the NavController from the NavHostFragment declared in activity_main.xml
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Tell AppBar which destinations are "top level" (no back arrow shown)
        appBarConfiguration = AppBarConfiguration(
            setOf(R.id.homeFragment)
        )

        // Connect ActionBar with NavController (auto-handles title + back button)
        setupActionBarWithNavController(navController, appBarConfiguration)
    }

    // Handle the ActionBar back button (←)
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}
