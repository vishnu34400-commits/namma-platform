package com.nammaplatform.activities

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nammaplatform.databinding.ActivitySplashBinding

/**
 * SplashActivity — entry point of the app.
 *
 * Shows a railway-themed splash with animated logo and title,
 * then transitions to MainActivity after a brief delay.
 *
 * Uses Handler (not Thread.sleep) so the main thread stays responsive.
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    // Delay before moving to MainActivity (in milliseconds)
    private val SPLASH_DELAY = 2500L

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startAnimations()

        // Navigate to MainActivity after delay
        handler.postDelayed({
            navigateToMain()
        }, SPLASH_DELAY)
    }

    /**
     * Runs a staggered animation:
     * 1. Logo fades + scales in
     * 2. App title fades in (delayed)
     * 3. Tagline fades in (further delayed)
     */
    private fun startAnimations() {
        // Start all views invisible
        binding.ivLogo.alpha = 0f
        binding.tvAppName.alpha = 0f
        binding.tvTagline.alpha = 0f
        binding.tvStation.alpha = 0f

        // Logo: fade in + scale up
        val logoFade = ObjectAnimator.ofFloat(binding.ivLogo, View.ALPHA, 0f, 1f).apply {
            duration = 700
        }
        val logoScaleX = ObjectAnimator.ofFloat(binding.ivLogo, View.SCALE_X, 0.6f, 1f).apply {
            duration = 700
        }
        val logoScaleY = ObjectAnimator.ofFloat(binding.ivLogo, View.SCALE_Y, 0.6f, 1f).apply {
            duration = 700
        }

        // App name: slide up + fade in
        binding.tvAppName.translationY = 40f
        val nameFade = ObjectAnimator.ofFloat(binding.tvAppName, View.ALPHA, 0f, 1f).apply {
            duration = 600
            startDelay = 400
        }
        val nameSlide = ObjectAnimator.ofFloat(binding.tvAppName, View.TRANSLATION_Y, 40f, 0f).apply {
            duration = 600
            startDelay = 400
        }

        // Tagline: fade in
        val tagFade = ObjectAnimator.ofFloat(binding.tvTagline, View.ALPHA, 0f, 1f).apply {
            duration = 500
            startDelay = 900
        }

        // Station text: fade in last
        val stationFade = ObjectAnimator.ofFloat(binding.tvStation, View.ALPHA, 0f, 0.7f).apply {
            duration = 500
            startDelay = 1200
        }

        AnimatorSet().apply {
            playTogether(logoFade, logoScaleX, logoScaleY, nameFade, nameSlide, tagFade, stationFade)
            start()
        }
    }

    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        // Custom transition: slide left
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish() // Don't let user go back to splash
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cancel pending navigation if activity is destroyed early
        handler.removeCallbacksAndMessages(null)
    }
}
