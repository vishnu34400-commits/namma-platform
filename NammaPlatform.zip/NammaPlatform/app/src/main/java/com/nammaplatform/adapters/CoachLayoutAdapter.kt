package com.nammaplatform.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.nammaplatform.R
import com.nammaplatform.databinding.ItemCoachBinding
import com.nammaplatform.utils.CoachType

/**
 * CoachLayoutAdapter — renders the horizontal coach strip.
 *
 * Each coach is a card showing:
 * - Coach label (Engine, S1, General, Ladies, etc.)
 * - Color-coded background by type
 * - Highlighted border for General and Ladies coaches
 * - Position number below the label
 *
 * Does NOT use ListAdapter because the list doesn't update dynamically.
 */
class CoachLayoutAdapter(
    private val coaches: List<String>
) : RecyclerView.Adapter<CoachLayoutAdapter.CoachViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CoachViewHolder {
        val binding = ItemCoachBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CoachViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CoachViewHolder, position: Int) {
        holder.bind(coaches[position], position + 1)
    }

    override fun getItemCount(): Int = coaches.size

    inner class CoachViewHolder(
        private val binding: ItemCoachBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(label: String, position: Int) {
            val context = binding.root.context
            val type = CoachType.from(label)

            binding.tvCoachLabel.text = label
            binding.tvCoachPosition.text = "#$position"

            // Apply color and styling based on coach type
            when (type) {
                CoachType.ENGINE -> {
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_engine)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_engine_text)
                    )
                    binding.coachCard.strokeWidth = 0
                }
                CoachType.GENERAL -> {
                    // HIGHLIGHTED — most important for rural passengers
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_general)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_general_text)
                    )
                    // Bold stroke to make it pop
                    binding.coachCard.strokeColor =
                        ContextCompat.getColor(context, R.color.coach_general_stroke)
                    binding.coachCard.strokeWidth = 4
                }
                CoachType.LADIES -> {
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_ladies)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_ladies_text)
                    )
                    binding.coachCard.strokeColor =
                        ContextCompat.getColor(context, R.color.coach_ladies_stroke)
                    binding.coachCard.strokeWidth = 4
                }
                CoachType.SLEEPER -> {
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_sleeper)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_sleeper_text)
                    )
                    binding.coachCard.strokeWidth = 0
                }
                CoachType.AC -> {
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_ac)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_ac_text)
                    )
                    binding.coachCard.strokeWidth = 0
                }
                CoachType.OTHER -> {
                    binding.coachCard.setCardBackgroundColor(
                        ContextCompat.getColor(context, R.color.coach_other)
                    )
                    binding.tvCoachLabel.setTextColor(
                        ContextCompat.getColor(context, R.color.coach_other_text)
                    )
                    binding.coachCard.strokeWidth = 0
                }
            }
        }
    }
}
