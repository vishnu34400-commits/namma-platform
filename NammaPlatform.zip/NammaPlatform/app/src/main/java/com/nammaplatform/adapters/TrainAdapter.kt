package com.nammaplatform.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammaplatform.R
import com.nammaplatform.databinding.ItemTrainBinding
import com.nammaplatform.models.Train

/**
 * TrainAdapter — displays a list of Train cards in a RecyclerView.
 *
 * Uses ListAdapter (not RecyclerView.Adapter) because:
 * - DiffUtil automatically calculates which items changed
 * - Only changed items are redrawn (efficient)
 * - Smooth animations on list updates are built in
 *
 * @param onTrainClick Callback invoked when user taps a train card
 */
class TrainAdapter(
    private val onTrainClick: (Train) -> Unit
) : ListAdapter<Train, TrainAdapter.TrainViewHolder>(TrainDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrainViewHolder {
        val binding = ItemTrainBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TrainViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TrainViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TrainViewHolder(
        private val binding: ItemTrainBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(train: Train) {
            binding.apply {
                tvTrainName.text = train.trainName
                tvTrainNumber.text = "Train #${train.trainNumber}"
                tvArrivalTime.text = train.arrivalTime
                tvPlatformNumber.text = "Platform ${train.platformNumber}"

                // Status chip — color-coded by status
                tvStatus.text = train.status
                val context = root.context
                if (train.status.equals("On Time", ignoreCase = true)) {
                    tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_on_time))
                    tvStatus.setBackgroundResource(R.drawable.bg_status_on_time)
                } else {
                    tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_late))
                    tvStatus.setBackgroundResource(R.drawable.bg_status_late)
                }

                // Coach preview — show first 4 coaches as a quick peek
                val coachPreview = train.coachSequence.take(4).joinToString(" → ")
                tvCoachPreview.text = coachPreview

                // Tap handler
                root.setOnClickListener { onTrainClick(train) }
            }
        }
    }

    /**
     * DiffCallback — tells RecyclerView how to compare items.
     * areItemsTheSame: are they the SAME object? (use unique ID)
     * areContentsTheSame: have the CONTENTS changed?
     */
    class TrainDiffCallback : DiffUtil.ItemCallback<Train>() {
        override fun areItemsTheSame(oldItem: Train, newItem: Train): Boolean {
            return oldItem.trainNumber == newItem.trainNumber
        }

        override fun areContentsTheSame(oldItem: Train, newItem: Train): Boolean {
            return oldItem == newItem
        }
    }
}
