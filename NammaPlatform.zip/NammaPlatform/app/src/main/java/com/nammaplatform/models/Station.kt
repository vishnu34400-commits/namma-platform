package com.nammaplatform.models

/**
 * Station — represents a railway station selectable in the app.
 */
data class Station(
    val id: String,
    val nameEnglish: String,
    val nameKannada: String
) {
    // Used by the Spinner adapter to display the station name
    override fun toString(): String = nameEnglish
}
