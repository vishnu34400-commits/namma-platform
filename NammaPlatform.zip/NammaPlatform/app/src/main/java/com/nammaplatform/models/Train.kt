package com.nammaplatform.models

import com.google.gson.annotations.SerializedName

/**
 * Train — the core data model for a single train entry.
 * Maps directly to the JSON structure in assets/trains.json.
 *
 * @param trainName       Human-readable train name (e.g. "Mysuru Express")
 * @param trainNumber     Official 5-digit train number
 * @param platformNumber  Platform number at this station (as String to handle "1A", "2B" etc.)
 * @param arrivalTime     Scheduled arrival time (e.g. "10:45 AM")
 * @param status          Current running status (e.g. "On Time", "Late by 10 min")
 * @param coachSequence   Ordered list of coach labels from engine end
 * @param stationName     Station this train stops at (optional, for multi-station support)
 */
data class Train(
    @SerializedName("trainName")     val trainName: String = "",
    @SerializedName("trainNumber")   val trainNumber: String = "",
    @SerializedName("platformNumber") val platformNumber: String = "",
    @SerializedName("arrivalTime")   val arrivalTime: String = "",
    @SerializedName("status")        val status: String = "",
    @SerializedName("coachSequence") val coachSequence: List<String> = emptyList(),
    @SerializedName("stationName")   val stationName: String = ""
)
