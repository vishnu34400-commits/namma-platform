package com.nammaplatform.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nammaplatform.models.Train
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * TrainRepository — single source of truth for train data.
 *
 * In MVVM, the Repository is the layer between ViewModel and data sources
 * (local JSON, database, or remote API). The ViewModel never touches raw
 * data directly — it always goes through the Repository.
 *
 * All IO work runs on Dispatchers.IO so the main thread is never blocked.
 */
class TrainRepository(private val context: Context) {

    private val gson = Gson()

    /**
     * Loads and parses all trains from assets/trains.json.
     * Returns an empty list (not a crash) on any error.
     */
    suspend fun getAllTrains(): List<Train> = withContext(Dispatchers.IO) {
        try {
            val jsonString = context.assets
                .open("trains.json")
                .bufferedReader()
                .use { it.readText() }

            if (jsonString.isBlank()) return@withContext emptyList()

            val type = object : TypeToken<List<Train>>() {}.type
            val trains: List<Train>? = gson.fromJson(jsonString, type)

            // Filter out any trains with missing critical fields
            trains?.filter { it.trainName.isNotBlank() && it.trainNumber.isNotBlank() }
                ?: emptyList()

        } catch (e: Exception) {
            e.printStackTrace()
            emptyList() // Graceful degradation — never crash on data errors
        }
    }

    /**
     * Returns the next [count] trains from the full list.
     * In a real app, this would filter by current time.
     */
    suspend fun getNextTrains(count: Int = 3): List<Train> {
        return getAllTrains().take(count)
    }

    /**
     * Filters trains by station name.
     */
    suspend fun getTrainsForStation(stationName: String): List<Train> {
        return getAllTrains().filter {
            it.stationName.equals(stationName, ignoreCase = true)
        }
    }
}
