package com.nammaplatform.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.nammaplatform.R
import com.nammaplatform.adapters.TrainAdapter
import com.nammaplatform.databinding.FragmentHomeBinding
import com.nammaplatform.viewmodel.TrainViewModel

/**
 * HomeFragment — the main screen users see after the splash.
 *
 * Displays:
 * - Station header
 * - Next 3 trains in a scrollable card list
 * - Loading indicator while trains are fetched
 * - Error state with retry button if loading fails
 *
 * Observes TrainViewModel via activityViewModels() so the ViewModel is
 * shared with TrainDetailFragment (same data, no re-fetch needed).
 */
class HomeFragment : Fragment() {

    // activityViewModels() shares ViewModel across all fragments in this Activity
    private val viewModel: TrainViewModel by activityViewModels()

    // ViewBinding — auto-nulled in onDestroyView to prevent memory leaks
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var trainAdapter: TrainAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeViewModel()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        trainAdapter = TrainAdapter { selectedTrain ->
            // User tapped a train card — save selection and navigate to detail
            viewModel.selectTrain(selectedTrain)
            findNavController().navigate(R.id.action_homeFragment_to_trainDetailFragment)
        }

        binding.rvTrains.apply {
            adapter = trainAdapter
            layoutManager = LinearLayoutManager(requireContext())
            // Improve performance since item height is fixed
            setHasFixedSize(true)
        }
    }

    private fun observeViewModel() {
        // Watch train list — update RecyclerView when data arrives
        viewModel.trains.observe(viewLifecycleOwner) { trains ->
            if (trains.isNullOrEmpty()) {
                showEmptyState()
            } else {
                showTrains()
                trainAdapter.submitList(trains)
                binding.tvTrainCount.text = "${trains.size} trains today"
            }
        }

        // Watch loading state — show/hide progress bar
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Watch errors — show Snackbar with retry option
        viewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG)
                    .setAction("Retry") { viewModel.loadTrains() }
                    .show()
                viewModel.clearError()
                showEmptyState()
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnRetry.setOnClickListener {
            viewModel.loadTrains()
        }
    }

    private fun showTrains() {
        binding.rvTrains.visibility = View.VISIBLE
        binding.layoutEmpty.visibility = View.GONE
    }

    private fun showEmptyState() {
        binding.rvTrains.visibility = View.GONE
        binding.layoutEmpty.visibility = View.VISIBLE
    }

    // IMPORTANT: Always null the binding in onDestroyView
    // The Fragment outlives its View — keeping a reference causes a memory leak
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
