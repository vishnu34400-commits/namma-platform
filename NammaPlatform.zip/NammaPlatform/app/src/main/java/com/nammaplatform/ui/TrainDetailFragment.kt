package com.nammaplatform.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammaplatform.adapters.CoachLayoutAdapter
import com.nammaplatform.databinding.FragmentTrainDetailBinding
import com.nammaplatform.utils.KannadaTTSHelper
import com.nammaplatform.viewmodel.TrainViewModel

/**
 * TrainDetailFragment — shows full info for the selected train.
 *
 * Displays:
 * - Large platform number board (railway-style)
 * - Train name, number, arrival time, status
 * - Horizontally scrollable coach layout strip
 * - "Speak" button for Kannada TTS announcement
 *
 * TTS lifecycle:
 *   onCreate  → TTS is initialized (takes ~500ms)
 *   onViewCreated → UI is set up, speak button registered
 *   onDestroyView → TTS is shut down to free resources
 */
class TrainDetailFragment : Fragment() {

    private val viewModel: TrainViewModel by activityViewModels()

    private var _binding: FragmentTrainDetailBinding? = null
    private val binding get() = _binding!!

    private var ttsHelper: KannadaTTSHelper? = null
    private var isTtsReady = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTrainDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeTTS()

        viewModel.selectedTrain.observe(viewLifecycleOwner) { train ->
            train?.let { bindTrainData(it) } ?: run {
                // Edge case: ViewModel cleared (process restart) — go back
                parentFragmentManager.popBackStack()
            }
        }
    }

    /**
     * Sets up TTS engine. Initialization is async (~500ms),
     * so speak button is disabled until onReady fires.
     */
    private fun initializeTTS() {
        binding.btnSpeak.isEnabled = false
        binding.btnSpeak.alpha = 0.5f

        ttsHelper = KannadaTTSHelper(
            context = requireContext(),
            onReady = {
                // Called on main thread when TTS engine is ready
                isTtsReady = true
                binding.btnSpeak.isEnabled = true
                binding.btnSpeak.alpha = 1.0f
            },
            onError = { errorMsg ->
                Toast.makeText(requireContext(), errorMsg, Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun bindTrainData(train: com.nammaplatform.models.Train) {
        binding.apply {
            // Railway board style — large platform number
            tvPlatformBoard.text = train.platformNumber
            tvPlatformLabel.text = "PLATFORM"

            // Train info
            tvDetailTrainName.text = train.trainName
            tvDetailTrainNumber.text = "#${train.trainNumber}"
            tvDetailArrival.text = "Arrives: ${train.arrivalTime}"
            tvDetailStatus.text = train.status

            // Status color
            val context = requireContext()
            if (train.status.equals("On Time", ignoreCase = true)) {
                tvDetailStatus.setTextColor(
                    androidx.core.content.ContextCompat.getColor(context, com.nammaplatform.R.color.status_on_time)
                )
            } else {
                tvDetailStatus.setTextColor(
                    androidx.core.content.ContextCompat.getColor(context, com.nammaplatform.R.color.status_late)
                )
            }

            // Coach info summary
            val generalIdx = train.coachSequence.indexOfFirst {
                it.equals("General", ignoreCase = true)
            }
            tvCoachInfo.text = if (generalIdx >= 0) {
                "General coach: Position ${generalIdx + 1} from engine"
            } else {
                "Coach sequence: ${train.coachSequence.size} coaches"
            }

            // Coach layout horizontal RecyclerView
            val coachAdapter = CoachLayoutAdapter(train.coachSequence)
            rvCoachLayout.apply {
                adapter = coachAdapter
                layoutManager = LinearLayoutManager(
                    requireContext(),
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                // Snap to first General coach on load
                val generalPos = train.coachSequence.indexOfFirst {
                    it.equals("General", ignoreCase = true)
                }
                if (generalPos > 0) {
                    post { scrollToPosition(maxOf(0, generalPos - 1)) }
                }
            }

            // Speak button
            btnSpeak.setOnClickListener {
                if (isTtsReady) {
                    ttsHelper?.speak(train)
                    btnSpeak.text = "🔊 ಮಾತನಾಡುತ್ತಿದೆ..."
                    btnSpeak.postDelayed({
                        btnSpeak.text = "🔊 ಪ್ರಕಟಣೆ ಓದಿ (Speak)"
                    }, 4000)
                } else {
                    Toast.makeText(requireContext(), "Speech engine loading...", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // CRITICAL: shut down TTS to prevent memory leak
        ttsHelper?.shutdown()
        ttsHelper = null
        _binding = null
    }
}
