package com.nammaplatform.utils

import androidx.annotation.ColorRes
import com.nammaplatform.R

/**
 * CoachType — classifies each coach label into a visual category.
 * Used by CoachLayoutAdapter to apply the correct color and icon.
 */
enum class CoachType {
    ENGINE, GENERAL, LADIES, SLEEPER, AC, OTHER;

    companion object {
        /**
         * Maps a raw coach label string (from JSON) to a CoachType.
         * Case-insensitive.
         */
        fun from(label: String): CoachType = when {
            label.equals("Engine", ignoreCase = true) -> ENGINE
            label.equals("General", ignoreCase = true) -> GENERAL
            label.equals("Ladies", ignoreCase = true) -> LADIES
            label.startsWith("S", ignoreCase = true) -> SLEEPER
            label.startsWith("A", ignoreCase = true) ||
            label.startsWith("B", ignoreCase = true) ||
            label.equals("CC", ignoreCase = true) ||
            label.equals("EC", ignoreCase = true) -> AC
            else -> OTHER
        }
    }
}
