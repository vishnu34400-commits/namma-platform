package com.nammaplatform.utils

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.nammaplatform.models.Train
import java.util.Locale

/**
 * KannadaTTSHelper — wraps Android's TextToSpeech API for Kannada announcements.
 *
 * Usage:
 *   val tts = KannadaTTSHelper(context)
 *   tts.speak(train)
 *   // In onDestroy():
 *   tts.shutdown()
 *
 * Handles:
 *   - TTS initialization delay (uses a ready callback)
 *   - Kannada locale unavailable (falls back to English)
 *   - Safe shutdown to prevent memory leaks
 */
class KannadaTTSHelper(
    private val context: Context,
    private val onReady: () -> Unit = {},
    private val onError: (String) -> Unit = {}
) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var useKannada = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Try to set Kannada locale first
                val kannadaLocale = Locale("kn", "IN")
                val result = tts?.setLanguage(kannadaLocale)

                useKannada = when (result) {
                    TextToSpeech.LANG_AVAILABLE,
                    TextToSpeech.LANG_COUNTRY_AVAILABLE,
                    TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE -> {
                        Log.d("TTS", "Kannada locale available ✓")
                        true
                    }
                    else -> {
                        // Fallback to English — common on older devices
                        Log.w("TTS", "Kannada not supported, falling back to English")
                        tts?.setLanguage(Locale.ENGLISH)
                        false
                    }
                }

                tts?.setSpeechRate(0.85f)  // Slightly slower for clarity
                tts?.setPitch(1.0f)
                isReady = true
                onReady()
            } else {
                Log.e("TTS", "TextToSpeech initialization failed with status: $status")
                onError("Speech engine is not available on this device.")
            }
        }
    }

    /**
     * Speaks the announcement for a given train.
     * Automatically chooses Kannada or English text based on device support.
     */
    fun speak(train: Train) {
        if (!isReady) {
            onError("Speech engine is still loading. Please try again.")
            return
        }

        val text = if (useKannada) {
            buildKannadaAnnouncement(train)
        } else {
            buildEnglishAnnouncement(train)
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "namma_announcement")
        Log.d("TTS", "Speaking: $text")
    }

    /**
     * Builds a Kannada announcement string for the train.
     * Example: "ಗಮನಿಸಿ. ರೈಲು ನಂಬರ್ 12613, ಮೈಸೂರು ಎಕ್ಸ್‌ಪ್ರೆಸ್, ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ನಂಬರ್ 2ಕ್ಕೆ ಬರುತ್ತಿದೆ."
     */
    private fun buildKannadaAnnouncement(train: Train): String {
        val platform = train.platformNumber
        val generalPosition = findGeneralCoachPosition(train)
        val ladiesPosition = findLadiesCoachPosition(train)

        return buildString {
            append("ಗಮನಿಸಿ. ")
            append("ರೈಲು ನಂಬರ್ ${train.trainNumber}, ")
            append("${train.trainName}, ")
            append("ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ನಂಬರ್ ${platform}ಕ್ಕೆ ಬರುತ್ತಿದೆ. ")
            if (generalPosition > 0) {
                append("ಸಾಮಾನ್ಯ ಬೋಗಿ, ಇಂಜಿನ್ ನಿಂದ ${generalPosition}ನೇ ಸ್ಥಾನದಲ್ಲಿದೆ. ")
            }
            if (ladiesPosition > 0) {
                append("ಮಹಿಳಾ ಬೋಗಿ, ${ladiesPosition}ನೇ ಸ್ಥಾನದಲ್ಲಿದೆ. ")
            }
            append("ದಯವಿಟ್ಟು ಸಾಲಿನಲ್ಲಿ ನಿಲ್ಲಿ.")
        }
    }

    /**
     * English fallback announcement when Kannada TTS is unavailable.
     */
    private fun buildEnglishAnnouncement(train: Train): String {
        val generalPosition = findGeneralCoachPosition(train)
        return buildString {
            append("Attention please. ")
            append("Train number ${train.trainNumber}, ${train.trainName}, ")
            append("is arriving on Platform number ${train.platformNumber}. ")
            if (generalPosition > 0) {
                append("General coach is coach number $generalPosition from the engine. ")
            }
            append("Please stand in line. Thank you.")
        }
    }

    /** Returns 1-based position of first General coach, or 0 if not found */
    private fun findGeneralCoachPosition(train: Train): Int {
        val idx = train.coachSequence.indexOfFirst {
            it.equals("General", ignoreCase = true)
        }
        return if (idx >= 0) idx + 1 else 0
    }

    /** Returns 1-based position of Ladies coach, or 0 if not found */
    private fun findLadiesCoachPosition(train: Train): Int {
        val idx = train.coachSequence.indexOfFirst {
            it.equals("Ladies", ignoreCase = true)
        }
        return if (idx >= 0) idx + 1 else 0
    }

    /**
     * Stops any ongoing speech.
     */
    fun stop() {
        tts?.stop()
    }

    /**
     * MUST be called in onDestroy() to free TTS resources.
     * Failing to call this causes memory leaks.
     */
    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
