package com.nammaplatform.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.nammaplatform.models.Train
import com.nammaplatform.repository.TrainRepository
import kotlinx.coroutines.launch

/**
 * TrainViewModel — bridges the UI (Fragments) and the data (Repository).
 *
 * Why AndroidViewModel (not ViewModel)?
 * We need Application context to pass to the Repository for asset loading.
 * AndroidViewModel safely holds Application context — it's NOT a memory leak
 * because Application lives as long as the app process itself.
 *
 * LiveData automatically updates the UI when data changes, and is
 * lifecycle-aware so it won't update destroyed/stopped fragments.
 */
class TrainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TrainRepository(application)

    // Internal mutable state — only ViewModel writes to these
    private val _trains = MutableLiveData<List<Train>>()
    private val _isLoading = MutableLiveData<Boolean>()
    private val _error = MutableLiveData<String?>()
    private val _selectedTrain = MutableLiveData<Train?>()

    // Public read-only state — Fragments observe these
    val trains: LiveData<List<Train>> = _trains
    val isLoading: LiveData<Boolean> = _isLoading
    val error: LiveData<String?> = _error
    val selectedTrain: LiveData<Train?> = _selectedTrain

    init {
        // Load trains as soon as ViewModel is created
        loadTrains()
    }

    /**
     * Loads all trains from the repository.
     * Runs in viewModelScope — automatically cancelled when ViewModel is destroyed.
     */
    fun loadTrains() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null

            try {
                val result = repository.getAllTrains()
                if (result.isEmpty()) {
                    _error.value = "No trains found. Check trains.json in assets."
                } else {
                    _trains.value = result
                }
            } catch (e: Exception) {
                _error.value = "Failed to load trains: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Selects a train to display in the detail screen.
     * HomeFragment calls this when user taps a train card.
     */
    fun selectTrain(train: Train) {
        _selectedTrain.value = train
    }

    /**
     * Clears any error state (e.g. after showing a Snackbar).
     */
    fun clearError() {
        _error.value = null
    }
}
